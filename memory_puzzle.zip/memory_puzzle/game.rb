require_relative "board.rb"
require_relative "card.rb"
require_relative "human_player.rb"
require_relative "computer_player.rb"

class Game

    def initialize
        @board = Board.new
        @previously_guessed_position = []

    end



end